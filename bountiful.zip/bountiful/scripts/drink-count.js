var currentOrderCount = localStorage.getItem('orderCount') || 0;
document.getElementById('order-count').textContent = currentOrderCount;