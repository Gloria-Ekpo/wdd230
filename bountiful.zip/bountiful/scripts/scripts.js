document.getElementById('dateModified').textContent = document.lastModified;
